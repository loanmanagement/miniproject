package com.lms.service;

import com.lms.dao.ILadDao;
import com.lms.dao.LadDaoImpl;
import com.lms.entity.ApprovedLoans;
import com.lms.entity.LoanApplication;
import com.lms.exception.LmsException;

public class LadServiceImpl implements ILadService {

	ILadDao ladDao=new LadDaoImpl();
	
	@Override
	public boolean isRejected(int applicationId) throws LmsException {
		
		return ladDao.isRejected(applicationId);
	}

	@Override
	public boolean isInterviewDatedUpdated(int loanApplication, int noOfDays)
			throws LmsException {
		
		return ladDao.isInterviewDatedUpdated(loanApplication, noOfDays);
	}

	@Override
	public boolean isApprovedOrRejectedAfterinterview(int loanApplication,
			String status) throws LmsException {
		
		return ladDao.isApprovedOrRejectedAfterinterview(loanApplication, status);
	}

	@Override
	public boolean isAdded(ApprovedLoans approvedLoans) throws LmsException {
		
		return ladDao.isAdded(approvedLoans);
	}

	@Override
	public LoanApplication findLoan(int id) throws LmsException {
		return ladDao.findLoan(id);
	}

}
