package com.lms.service;

import com.lms.entity.Users;
import com.lms.exception.LmsException;

public interface IUserService {
	public boolean addUser(Users users)throws LmsException;
	public boolean authenticUser(String[] credential)throws LmsException;
}
