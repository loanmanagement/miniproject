package com.lms.view;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import com.lms.entity.CustomerDetails;
import com.lms.entity.LoanProgramsOffered;
import com.lms.entity.Users;
import com.lms.exception.LmsException;
import com.lms.service.AdminServiceImpl;
import com.lms.service.CustomerServiceImpl;
import com.lms.service.IAdminService;
import com.lms.service.ICustomerService;
import com.lms.service.ILadService;
import com.lms.service.IUserService;
import com.lms.service.LadServiceImpl;
import com.lms.service.UserServiceImpl;

public class Main {

	public static void main(String[] args) throws NumberFormatException,
			IOException, LmsException {
		IUserService userservice = new UserServiceImpl();
		IAdminService adminService = new AdminServiceImpl();
		Users users = new Users();
		ICustomerService customerService = new CustomerServiceImpl();
		CustomerDetails customer = new CustomerDetails();
		ILadService lad= new LadServiceImpl();
		LoanProgramsOffered loanProgramOffered = new LoanProgramsOffered();

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int ch;
		System.out.println("-----------------------------------");
		System.out.println("Welcome to ABC Banking");
		System.out.println("Press 1 to visit as customer");
		System.out.println("Press 2 to enter as a LAD");
		System.out.println("Press 3 to enter as a Admin");
		System.out.println("Press 0 to exit");
		System.out.println("-----------------------------------");
		ch = Integer.parseInt(br.readLine());

		switch (ch) {
		//CUSTOMER
		case 1:

			break;
        //LAD
		case 2:

			System.out.println("Alredy an LAD?? Press 1 to login");
			System.out.println("Press 2 to register yourself");
			System.out.println("Press 0 to exit");
			int chLad = Integer.parseInt(br.readLine());
			switch (chLad) {
			case 1:
				String[] credentialLad = new String[2];
				System.out.println("Enter username");
				credentialLad[0] = br.readLine();
				System.out.println("enter Password");
				credentialLad[1] = br.readLine();
				boolean isAuthenticLad = userservice.authenticUser(credentialLad);
				if (isAuthenticLad) {
					System.out.println("Press 1 to view all");
					System.out.println("Press 2 to view specific loan program");
					System.out.println("Press 3 to reject before appointment");
					System.out.println("Press 4 to schedule appointment");
					System.out.println("Press 5 to approve Or Reject after Appointment");
					System.out.println("Press 0 to exit ");
					int operationLad= Integer.parseInt(br.readLine());
					switch (operationLad){
					case 0:
						System.exit(0);
						break;
					case 1:
						List<LoanProgramsOffered> viewAllLoans=null;
						viewAllLoans=adminService.viewAll();
						if(viewAllLoans==null){
							System.out.println("No loan Program exist for this bank");
						}else{
							for(LoanProgramsOffered loansPrograms:viewAllLoans){
								System.out.println(loansPrograms);
							}
						}
						break;
					case 2:
						System.out.println("Enter loan program Name");
						 LoanProgramsOffered specificLoan=adminService.viewSprcific(br.readLine());
						 System.out.println(specificLoan);
						break;
					case 3:
						System.out.println("Enter id to be Deleted");
						int toDeleteId= Integer.parseInt(br.readLine());
						boolean rejected=lad.isRejected(toDeleteId);
						if(rejected){
							System.out.println("Application Deleted Successfully");
						}
						else{
							System.out.println("Cannot delete either Desn't exist or some other problem");
						}
						break;
					case 4:
						System.out.println("Enter Application id ");
						int appIdAppointment= Integer.parseInt(br.readLine());
						System.out.println("Enter no of days after which Appointment is to be set");
						int noOfDays= Integer.parseInt(br.readLine());
						boolean isAppointmentSet=(lad.isInterviewDatedUpdated(appIdAppointment, noOfDays));
						if(isAppointmentSet){
							System.out.println("Appointment Date set successfully");
						}else{
							System.out.println("Cannot set appointment Id");
						}
						break;
					case 5:
						System.out.println("Enter Application Id");
						int appID=Integer.parseInt(br.readLine());
						System.out.println("Enter Status");
						String status= br.readLine();
						boolean isStatusUpdated= lad.isApprovedOrRejectedAfterinterview(appID, status);
						if(isStatusUpdated){
							System.out.println("Status Updated Successfully");
						}else{
							System.out.println("cannot update");
						}
						break;
						default:
							System.out.println("Invalid Choice");
							break;
					}
				}else{
					System.out.println("Invalid USERNAME or PASSWORD");
				}
			
			break;
			}
        //ADMIN
		case 3:
			System.out.println("Alredy an Admin?? Press 1 to login");
			System.out.println("Press 2 to register yourself");
			System.out.println("Press 0 to exit");
			int chAdmin = Integer.parseInt(br.readLine());
			switch (chAdmin) {
			case 1:
				String[] credential = new String[2];
				System.out.println("Enter username");
				credential[0] = br.readLine();
				System.out.println("enter Password");
				credential[1] = br.readLine();
				boolean isAuthentic = userservice.authenticUser(credential);
				if (isAuthentic) {
					int operations;
					System.out.println("Press 1 to ADD loan program");
					System.out.println("Press 2 to DELETE");
					System.out.println("Press 3 to UPDATE Loan Program(all Parameters)");
					System.out.println("press 4 to UPDATE just Rate");
					System.out.println("Press 5 VIEW all");
					System.out.println("Press 6 to VIEW SPECIFIC Loan Program");
					System.out.println("Press 0 to exit");
					operations = Integer.parseInt(br.readLine());
					switch (operations) {
					case 0:
						System.out.println("Application exited successfully!!");
						System.exit(0);

						break;
					case 1:
						System.out.println("enter program name");
						  loanProgramOffered.setProgramName(br.readLine());
						  System.out.println("enter description");
						  loanProgramOffered.setDescription(br.readLine());
						  System.out.println("enter type");
						  loanProgramOffered.setType(br.readLine());
						  System.out.println("enter duration in years");
						  loanProgramOffered.setDurationInYears
						  (Integer.parseInt(br.readLine()));
						  System.out.println("enter min loan amount");
						  loanProgramOffered.setMinLoanAmount(Integer.parseInt(br.readLine()));
						  System.out.println("enter max loan amount");
						  loanProgramOffered.setMaxLoanAmount(Integer.parseInt(br.readLine()));
						  System.out.println("enter rate");
						  loanProgramOffered.setRateOfInterest
						  (Integer.parseInt(br.readLine()));
						  System.out.println("enter proofs");
						  loanProgramOffered.setProofsRequired(br.readLine());
						   boolean isInserted=adminService.isLoanProgramInserted(loanProgramOffered);
						  if(isInserted)
							  System.out.println("Added Successfully");
						  else
							  System.out.println("OOPs Something went wrong");
						break;
						
					case 2:
						System.out.println("Enter program name");
						  boolean isDeleted=adminService.isDeleted(br.readLine());
						  if(isDeleted)
							  System.out.println("Loan Program Deleted");
						  else
							  System.out.println("OOPS something went Wrong");
						break;
					case 3:
						System.out.println("Enter program name that needs to be updated");
						String programName=br.readLine();
						System.out.println("Enter the revised rate of interest");
						int rate=Integer.parseInt(br.readLine());
						System.out.println("Enter the min amount to be granted");
						int minAmount= Integer.parseInt(br.readLine());
						System.out.println("Enter the max Amount");
						int maxAmount= Integer.parseInt(br.readLine());
						System.out.println("enter the id required");
						String id=br.readLine();
						boolean isUpdatedLoanProgram=adminService.isUpdated(programName, rate, minAmount, maxAmount, id);
						if(isUpdatedLoanProgram)
							System.out.println("Updated SUCCESSFULLY");
						else
							System.out.println("OOPS something went wrong");
						break;
					case 4:
						System.out.println("enter program name");
						String programNameToBeUpdated=br.readLine();
						System.out.println("enter rate");
						int newRate=Integer.parseInt(br.readLine());
						boolean isRateUpdated=adminService.isRateUpdated(programNameToBeUpdated, newRate);
						if(isRateUpdated)
							System.out.println("UPDATED SUCCESSFULLY");
						else
							System.out.println("OOPS something went wrong");
						break;
					case 5:
						List<LoanProgramsOffered> viewAllLoans=null;
						viewAllLoans=adminService.viewAll();
						if(viewAllLoans==null){
							System.out.println("No loan Program exist for this bank");
						}else{
							for(LoanProgramsOffered loansPrograms:viewAllLoans){
								System.out.println(loansPrograms);
							}
						}
						
						
						break;
					case 6:

						System.out.println("Enter loan program Name");
						 LoanProgramsOffered specificLoan=adminService.viewSprcific(br.readLine());
						 System.out.println(specificLoan);
						break;
					default:
						System.out.println("Invalid Choice");
						break;
					}
				} else {
					System.out.println("Invalid USERNAME or PASSWORD");
				}

				break;
			case 2:
				System.out.println("username");
				users.setLoginId(br.readLine());
				System.out.println("password");
				users.setPassword(br.readLine());
				System.out.println("role");
				users.setRole(br.readLine());
				boolean isInsertedAdmin = userservice.addUser(users);
				if (isInsertedAdmin){
					
					System.out.println("Admin added successfully");
				}
				else
					System.out.println("OOPS something went wrong");
				break;
			case 0:
				System.exit(0);
				break;
			default:
				System.out.println("Invalid choice");
				break;

			}
			break;

		case 0:
			System.out.println("Thank You for considering us!!!");
			System.exit(0);
			break;
		default:
			System.out.println("Invalid choice");
			break;
		}

	}

}
