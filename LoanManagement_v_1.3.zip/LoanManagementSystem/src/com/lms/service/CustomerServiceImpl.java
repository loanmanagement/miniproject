package com.lms.service;

import com.lms.dao.CustomerDaoImpl;
import com.lms.dao.ICustomerDao;
import com.lms.entity.CustomerDetails;
import com.lms.entity.LoanApplication;
import com.lms.exception.LmsException;

public class CustomerServiceImpl implements ICustomerService 
{
	ICustomerDao customerDao = new CustomerDaoImpl();
	@Override
	public int registerCustomer(CustomerDetails customer) throws LmsException {
		return customerDao.registerCustomer(customer);
	}

	@Override
	public int applyLoan(LoanApplication loan) throws LmsException {
		return customerDao.applyLoan(loan);
	}

	@Override
	public LoanApplication viewApplicationStatus(int applicationId)
			throws LmsException {
		return customerDao.viewApplicationStatus(applicationId);
	}

}
