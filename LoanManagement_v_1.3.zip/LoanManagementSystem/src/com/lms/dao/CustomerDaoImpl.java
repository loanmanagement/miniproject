package com.lms.dao;

import javax.persistence.EntityManager;

import com.lms.entity.CustomerDetails;
import com.lms.entity.LoanApplication;
import com.lms.exception.LmsException;
import com.lms.util.JPAUtil;

public class CustomerDaoImpl implements ICustomerDao
{
	private EntityManager entityManager = JPAUtil.getEntityManager();
	
	@Override
	public int registerCustomer(CustomerDetails customer) throws LmsException {
		System.out.println(customer.getDob());
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(customer);
			entityManager.getTransaction().commit();
		} catch (Exception e) {
		e.printStackTrace();
			throw new LmsException(e.getMessage());
		}
		System.out.println(customer.getDob());
		return customer.getCustomerId();
		
	}

	@Override
	public int applyLoan(LoanApplication loan)	throws LmsException 
	{
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(loan);
			entityManager.getTransaction().commit();
		} catch (Exception e) {
		e.printStackTrace();
			throw new LmsException(e.getMessage());
		}
		return loan.getApplicationId();
	}
	@Override
	public LoanApplication viewApplicationStatus(int applicationId)
			throws LmsException {
		LoanApplication loan = entityManager.find(LoanApplication.class, applicationId);
		if(loan != null)
		{
			return loan;
		}
			return null;
		
		
	}

}
