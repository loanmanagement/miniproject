package com.lms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.lms.entity.LoanProgramsOffered;
import com.lms.exception.LmsException;
import com.lms.util.JPAUtil;

public class AdminDaoImpl implements IAdminDao {
	private EntityManager entityManager;

	public AdminDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public boolean isLoanProgramInserted(LoanProgramsOffered loanProgramsOffered)
			throws LmsException {
		boolean isInserted = false;
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(loanProgramsOffered);
			entityManager.getTransaction().commit();
			isInserted = true;
		} catch (Exception e) {

			throw new LmsException(e.getMessage());
		}
		return isInserted;
	}

	@Override
	public boolean isDeleted(String programName) throws LmsException {
		boolean isDeleted = false;
		LoanProgramsOffered loanProgramsOffered;
		loanProgramsOffered = entityManager.find(LoanProgramsOffered.class,
				programName);
		entityManager.getTransaction().begin();
		try {
			if (loanProgramsOffered == null) {
				System.out.println("Not Found");
			} else {
				entityManager.remove(loanProgramsOffered);
				isDeleted = true;
			}
		} catch (Exception e) {

		
			throw new LmsException(e.getMessage());
		}
		entityManager.getTransaction().commit();
		return isDeleted;
	}

	@Override
	public boolean isUpdated(String programName, int rate, int minAmount,
			int maxAmount, String idRequired) throws LmsException {
		boolean isUpdated = false;
		LoanProgramsOffered loanProgramsOffered;

		try {
			loanProgramsOffered = entityManager.find(LoanProgramsOffered.class,
					programName);
			if (loanProgramsOffered != null) {
				entityManager.getTransaction().begin();
				loanProgramsOffered.setRateOfInterest(rate);
				loanProgramsOffered.setMinLoanAmount(minAmount);
				loanProgramsOffered.setMaxLoanAmount(maxAmount);
				loanProgramsOffered.setProofsRequired(idRequired);
				entityManager.getTransaction().commit();
				isUpdated = true;

			} else {
				System.out.println("Loan program not Found");
			}
		} catch (Exception e) {

		
			throw new LmsException(e.getMessage());
		}
		return isUpdated;
	}

	@Override
	public List<LoanProgramsOffered> viewAll() throws LmsException {
		List<LoanProgramsOffered> allLoansList;
		try {
			TypedQuery<LoanProgramsOffered> qry = entityManager.createQuery(
					"from LoanProgramsOffered", LoanProgramsOffered.class);

			allLoansList = qry.getResultList();
		} catch (Exception e) {
			throw new LmsException(e.getMessage());
		}
		return allLoansList;
	}

	@Override
	public LoanProgramsOffered viewSprcific(String name) throws LmsException {

		LoanProgramsOffered specificLoan = null;
		try {
			TypedQuery<LoanProgramsOffered> qry = entityManager.createQuery(
					"from LoanProgramsOffered where programName=:nameOfLoan",
					LoanProgramsOffered.class);
			qry.setParameter("nameOfLoan", name);
			specificLoan = qry.getSingleResult();
		} catch (Exception e) {
			
			throw new LmsException(e.getMessage());
		}

		return specificLoan;
	}

	@Override
	public boolean isRateUpdated(String programName, int rate)
			throws LmsException {
		boolean isRateUpdated = false;
		LoanProgramsOffered loanProgramsOffered;

		try {
			loanProgramsOffered = entityManager.find(LoanProgramsOffered.class,
					programName);
			if (loanProgramsOffered != null) {
				entityManager.getTransaction().begin();
				loanProgramsOffered.setRateOfInterest(rate);
				
				entityManager.getTransaction().commit();
				isRateUpdated = true;

			} else {
				System.out.println("Loan program not Found");
			}
		} catch (Exception e) {

		
			throw new LmsException(e.getMessage());
		}
		return isRateUpdated;
		
	}

}
