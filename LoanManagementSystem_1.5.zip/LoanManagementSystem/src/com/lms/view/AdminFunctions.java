package com.lms.view;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import com.lms.entity.CustomerDetails;
import com.lms.entity.LoanProgramsOffered;
import com.lms.entity.Users;
import com.lms.exception.LmsException;
import com.lms.service.AdminServiceImpl;
import com.lms.service.CustomerServiceImpl;
import com.lms.service.IAdminService;
import com.lms.service.ICustomerService;
import com.lms.service.ILadService;
import com.lms.service.IUserService;
import com.lms.service.LadServiceImpl;
import com.lms.service.UserServiceImpl;

public class AdminFunctions {
	
public void AdminOperations() throws LmsException, NumberFormatException, IOException{
	IUserService userservice = new UserServiceImpl();
	IAdminService adminService = new AdminServiceImpl();
	Users users = new Users();
	ICustomerService customerService = new CustomerServiceImpl();
	CustomerDetails customer = new CustomerDetails();
	ILadService lad= new LadServiceImpl();
	LoanProgramsOffered loanProgramOffered = new LoanProgramsOffered();

	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

	do{
	System.out.println("Alredy an Admin?? Press 1 to login");
	System.out.println("Press 2 to register yourself");
	System.out.println("Press 0 to exit");
	int chAdmin = Integer.parseInt(br.readLine());
	switch (chAdmin) {
	case 1:
		AfterLoginAdmin afterLoginAdmin= new AfterLoginAdmin();
		afterLoginAdmin.afterLoginAdmin();
		break;
	case 2:
		System.out.println("username");
		users.setLoginId(br.readLine());
		System.out.println("password");
		users.setPassword(br.readLine());
		
		users.setRole("ADMIN");
		try {
			boolean isInsertedAdmin = userservice.addUser(users);
			if (isInsertedAdmin){
				
				System.out.println("Admin added successfully");
			}
			else{
				System.out.println("OOPS something went wrong");
			}
		} catch (LmsException e) {
			
			System.out.println("PLEASE CHECK THE LENGTH OF USERNAME OR USERNAME ALREDY EXIST try something else!!!");
		}
			break;
	case 0:
		System.out.println("Application exited successfully!!");
		System.exit(0);
		break;
	default:
		System.out.println("Invalid choice");
		break;

	}
	}while(true);

	
}	
}

