package com.lms.service;

import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.lms.dao.ILadDao;
import com.lms.dao.LadDaoImpl;
import com.lms.entity.ApprovedLoans;
import com.lms.entity.LoanApplication;
import com.lms.exception.LmsException;
import com.lms.util.JPAUtil;

public class LadServiceImpl implements ILadService {
	static Logger logger=Logger.getRootLogger();
	private EntityManager entityManager;


	ILadDao ladDao=new LadDaoImpl();
	public LadServiceImpl() {
		entityManager = JPAUtil.getEntityManager();
		PropertyConfigurator.configure("resources//log4j.properties");
	}
	
	@Override
	public boolean isRejected(int applicationId) throws LmsException {
		logger.info("successful");
		return ladDao.isRejected(applicationId);
	}

	@Override
	public boolean isInterviewDatedUpdated(int loanApplication, int noOfDays)
			throws LmsException {
		logger.info("successful");
		return ladDao.isInterviewDatedUpdated(loanApplication, noOfDays);
	}

	@Override
	public boolean isApprovedOrRejectedAfterinterview(int loanApplication,
			String status) throws LmsException {
		logger.info("successful");
		return ladDao.isApprovedOrRejectedAfterinterview(loanApplication, status);
	}

	@Override
	public boolean isAdded(ApprovedLoans approvedLoans) throws LmsException {
		logger.info("successful");
		return ladDao.isAdded(approvedLoans);
	}

	@Override
	public LoanApplication findLoan(int id) throws LmsException {
		logger.info("successful");
		return ladDao.findLoan(id);
	}

}
