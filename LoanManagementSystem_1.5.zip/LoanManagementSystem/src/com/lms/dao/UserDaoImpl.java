package com.lms.dao;



import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.lms.entity.Users;
import com.lms.exception.LmsException;
import com.lms.util.JPAUtil;


public class UserDaoImpl implements IUserDao {
	static Logger logger=Logger.getRootLogger();
	
private EntityManager entityManager;
public UserDaoImpl() {
	entityManager=JPAUtil.getEntityManager();
	PropertyConfigurator.configure("resources//log4j.properties");
}

/*********************************************************************************
 *  - Author        : LMS TEAM 
 *  - Creation Date : Dec,2017
 *  - Function      : addUser()
 *  - Return type   : boolean
 *  - Description   : To add users
 *  - Exception     : LmsException
*********************************************************************************/
	@Override
	public boolean addUser(Users users) throws LmsException {
		boolean isInserted= false;
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(users);
			entityManager.getTransaction().commit();
			isInserted=true;
		} catch (Exception e) {
			logger.error("failed ");
			throw new LmsException(e.getMessage());
		}
		logger.info("successful");
		return isInserted;
	}
	public boolean authenticUser(String[] credential) throws LmsException {
		boolean isAuthentic=false;
		Users users;
		users=entityManager.find(Users.class, credential[0]);
		if(users!=null) {
			if(users.getLoginId().equals(credential[0]) && users.getPassword().equals(credential[1])) {
				isAuthentic=true;
			}
		}
		
		return isAuthentic;
	}
}
	
